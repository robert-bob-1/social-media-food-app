package com.example.application.views.components;

public class UserView {
}
